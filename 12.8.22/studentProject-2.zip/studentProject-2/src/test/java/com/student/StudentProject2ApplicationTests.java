package com.student;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentProject2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
