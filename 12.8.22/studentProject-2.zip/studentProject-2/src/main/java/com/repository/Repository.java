package com.repository;

public interface Repository {

}
