package com.student.service;

import com.student.entity.Student;

public interface StudentService {

	String createStudent(Student student);

}
