package studentmanagment;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class App {
	public static void main(String[] args) {
		 // Create Configuration
        Configuration configuration = new Configuration();
        configuration.configure("hibernate.cfg.xml");
        configuration.addAnnotatedClass(Details.class);
 
        // Create Session Factory
        SessionFactory sessionFactory = configuration.buildSessionFactory();
 
        // Initialize Session Object
        Session session = sessionFactory.openSession();
 
        Details d = new Details();
 
        
       d.setFirstName("abc");
       d.setAddress("delhi");
       d.setCourse("btech");
       d.setLastName("hshsh");
       d.setAge(66);
       
        session.beginTransaction();
 
        // Here we have used
        // save() method of JPA
        session.save(d);
 
        session.getTransaction().commit();
    }
	}

