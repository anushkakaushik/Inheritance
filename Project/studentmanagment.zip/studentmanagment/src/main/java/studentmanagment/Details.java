package studentmanagment;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="details")
//PoJo class
public class Details {
@Id
@Column(name="age")
private int age;
@Column(name="FirstName")
private String firstName;
@Column(name="LastName")
private String lastName;

@Column(name="Address")
 String address;

@Column(name="Course")
private String course;

public int getAge()
{ 
	return age; 
}
public void setAge(int Age)
{
	this.age=age;
}
public String getFirstName() 
{
	return firstName; 
}

public void setFirstName(String newfirstName)
{
    this.firstName = newfirstName;
}
public String getLastName() 
{
	return lastName; 
}
public void setLastName(String newlastName)
{
    this.lastName = newlastName;
}
public String getAddress() 
{
	return address; 
}
public void setAddress(String newaddress)
{
    this.address = newaddress;
}
public String getCourse() 
{
	return course; 
}
public void setCourse(String newcourse)
{
    this.course = newcourse;
}



}

