package junit.example.junit;

public class BasicSalaryCalculator {
private double basicsalary;
//public double getBasicSalary();
//{
//	
//}
public double getBasicsalary() {
	return basicsalary;
}
public void setBasicsalary(double basicsalary) {
//	this.basicsalary = basicsalary;
	if(basicSalary<0)
	{
		throw new IllegalArgumentException("negative salary");
		this.basicsalary = basicsalary;
	}
	public double getGrossSalary() {
		return this.basicsalary +getSocialInsurance() +getAdditionalBonus();
	}
	
}
}
