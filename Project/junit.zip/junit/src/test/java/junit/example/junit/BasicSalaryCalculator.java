package junit.example.junit;

import junit.framework.TestCase;

 class BasicSalaryCalculator  {
private BasicSalaryCalculator basicSalaryCalculator;
@BeforeEach
void init()
{
	basicSalaryCalculator =new BasicSalaryCalculator();
}
@Test
void t() {
	double basicSalary = 4000;
	basicSalaryCalculator.setBasicSalary(basicSalary);
}
}
