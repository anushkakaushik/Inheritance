package junit.example.junit;

public @interface Test {

}
