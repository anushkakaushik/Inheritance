package studentMgmCRUD;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;



import crud.hibernate.dao.StudentDao;

public class StudMgmTest {
private StudentDao sd;
@Before
public void setUp() throws Exception {
	sd = new StudentDao();
}
@After
public void tearDown() throws Exception {
	sd = null;
}
@Test
public final void testAdd() {
//	assertEquals(sd.deleteStudent());
}
}
