package studentMgmCRUD.Dao;

import org.hibernate.Session;
import org.hibernate.Transaction;
import java.util.List;


import jakarta.persistence.EntityTransaction;

import studMgmCRUD.util.HibernateUtil;
import studentMgmCRUD.model.Student;

class StudentDao {

		 public void saveStudent(Student student) {
			 @SuppressWarnings("deprecation")
			
			 	Transaction transaction = null;
			 	try(Session session = HibernateUtil.getSessionFactory().openSession()){
			 		transaction = session.beginTransaction();
//			 		Save object
			 		session.save(student);
//			 		commit
			 		transaction.commit();}
			 		catch (Exception e) {
			 			if(transaction != null) {
			 			}
			 			transaction.rollback();
			 		}
			 	
		 }
		 

		    /**
		     * Update Student
		     * @param student
		     */
		    public void updateStudent(Student student) {
		        Transaction transaction = null;
		        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
		            // start a transaction
		            transaction = session.beginTransaction();
		            // save the student object
		            session.update(student);
		            // commit transaction
		            transaction.commit();
		        } catch (Exception e) {
		            if (transaction != null) {
		                transaction.rollback();
		            }
		            e.printStackTrace();
		        }
		    }

		 

		    /**
		     * Delete Student
		     * @param id
		     */
		    public void deleteStudnet(int id) {

		 

		        Transaction transaction = null;
		        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
		            // start a transaction
		            transaction = session.beginTransaction();

		 

		            // Delete a instructor object
		            Student student = session.get(Student.class, id);
		            if (student != null) {
		                session.delete(student);
		                System.out.println("student is deleted");
		            }

		 

		            // commit transaction
		            transaction.commit();
		        } catch (Exception e) {
		            if (transaction != null) {
		                transaction.rollback();
		            }
		            e.printStackTrace();
		        }
		    }

		 

		    /**
		     * Get Studnet By ID
		     * @param id
		     * @return
		     */
		    public Student getStudent(int id) {

		 

		        Transaction transaction = null;
		        Student student = null;
		        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
		            // start a transaction
		            transaction = session.beginTransaction();
		            // get an instructor object
		            student = session.get(Student.class, id);
		            // commit transaction
		            transaction.commit();
		        } catch (Exception e) {
		            if (transaction != null) {
		                transaction.rollback();
		            }
		            e.printStackTrace();
		        }
		        return student;
		    }
		    
		    /**
		     * Get all Student
		     * @return
		     */
		    @SuppressWarnings("unchecked")
		    public List<Student> getAllStudent() {

		 

		        Transaction transaction = null;
		        List<Student> listOfStudent = null;
		        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
		            // start a transaction
		            transaction = session.beginTransaction();
		            // get an instructor object
		            
		            listOfStudent = session.createQuery("from Student").getResultList();
		            
		            // commit transaction
		            transaction.commit();
		        } catch (Exception e) {
		            if (transaction != null) {
		                transaction.rollback();
		            }
		            e.printStackTrace();
		        }
		        return listOfStudent;
		    }
	}

