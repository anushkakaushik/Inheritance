package studentMgmCRUD.hibernate;
import java.util.List;

import crud.hibernate.dao.StudentDao;
//import crud.hibernate.dao.StudentDao;
//import studentMgmCRUD.dao.StudentDao;
import studentMgmCRUD.model.Student;
public class App {
public static void main(String[] args) {
	Student student = new Student();
	student.setId(101);
	student.setEmail("B Tech");
	student.setFirstname("hfgfdhd");
	student.setLastname("Priya");
	 Student student2 = new Student();
	 student2.setId(102);
	 student2.setEmail("BCA");
	 student2.setFirstname("yghgj");
	 student2.setLastname("Puja");
	
	StudentDao studentDao = new StudentDao();
    studentDao.saveStudent(student);
  
 
    studentDao.deleteStudent(103);
    studentDao.saveStudent(student2);
//    / Get all instructors
    List<Student> students = studentDao.getAllStudents();
    students.forEach(studentTemp -> System.out.println(studentTemp.getStudentName()));
	
}
}

